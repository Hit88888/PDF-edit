# PDF Image Editor — Edge Extension

Insert, position, resize, and rotate images inside any PDF — entirely in your browser, no servers, no accounts.

---

## How to install (unpacked extension)

1. Open **edge://extensions** in Microsoft Edge
2. Enable **Developer mode** (toggle, top-right)
3. Click **Load unpacked**
4. Select the **`extension/`** folder from this project
5. The extension icon appears in your toolbar

### Required: Allow access to local files

If you want to edit PDFs from your **local disk** (`file://…`):

1. Go to **edge://extensions**
2. Click **Details** under "PDF Image Editor"
3. Enable **"Allow access to file URLs"**

Without this, the editor can still open PDFs from websites (http/https) but not from your hard drive.

---

## How to use

1. Open any PDF in Edge (local file or website link)
2. Click the **PDF Image Editor icon** in the toolbar
3. The popup shows **"PDF detected"** → click **"Open in Editor"**
4. The editor loads in the same tab
5. Use the floating toolbar on the right to:
   - **Add Image** — insert PNG, JPG, WebP, or SVG files
   - Drag, resize, rotate, flip, and reorder images
   - Adjust opacity with the slider
   - Lock objects to prevent accidental moves
6. Click **Save PDF** (or **Ctrl+S**) — the edited PDF downloads with the original filename
7. The editor tab closes automatically after saving

---

## Keyboard shortcuts

| Key | Action |
|-----|--------|
| `Ctrl+Z` | Undo |
| `Ctrl+Shift+Z` / `Ctrl+Y` | Redo |
| `Ctrl+S` | Save PDF |
| `Ctrl+D` | Duplicate selected image |
| `Ctrl+A` | Open Add Image dialog |
| `Delete` / `Backspace` | Delete selected image |
| `Arrow keys` | Nudge selected image (1 px) |
| `Shift+Arrow` | Nudge selected image (10 px) |
| `Ctrl++` / `Ctrl+-` | Zoom in / out |
| `Ctrl+0` | Reset zoom |

**On selected image:**
- **Mouse wheel** — rotate
- **Ctrl+drag** — duplicate and drag

---

## Folder structure

```
extension/
├── manifest.json          MV3 manifest
├── background.js          Service worker — handles tab navigation + downloads
├── popup.html/css/js      Extension action popup
├── viewer.html/css        PDF editor page
├── js/
│   ├── viewer.js          Main orchestrator
│   ├── pdfRenderer.js     PDF.js rendering (virtualised)
│   ├── fabricOverlay.js   Fabric.js canvas overlay management
│   ├── toolbar.js         Floating draggable toolbar
│   ├── history.js         Undo/Redo command stack
│   ├── saveManager.js     pdf-lib save pipeline
│   └── snapGuides.js      Snap-to-edge/center guide lines
├── lib/
│   ├── pdf.mjs            PDF.js 4.4.168 (vendored)
│   ├── pdf.worker.mjs     PDF.js worker (vendored)
│   ├── fabric.min.js      Fabric.js 6.4.0 (vendored)
│   └── pdf-lib.min.js     pdf-lib 1.17.1 (vendored)
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── generate-icons.js      Regenerate PNG icons (node generate-icons.js)
├── TASKS.md               Progress tracking
└── README.md              This file
```

---

## Rebuilding icons

```bash
cd extension
node generate-icons.js
```

---

## Known Platform Limitations

These are hard constraints of the browser extension platform — not bugs or shortcuts.

### 1. Edge's built-in PDF viewer cannot be overlaid or extended

Edge's native PDF viewer is an internal, sandboxed renderer. Extensions have **zero access** to it — they cannot attach a DOM or canvas layer on top of it, read its scroll/zoom state, or intercept its page geometry. This is a security boundary enforced by Chromium/Edge and cannot be worked around.

**What this means:** When you click "Open in Editor," the extension loads its **own** PDF viewer (built on PDF.js) in the same tab. You temporarily lose Edge's native features (text highlighting, form filling, Read Aloud, etc.) while in the editor. After saving and downloading the edited PDF, you can open it again normally to use Edge's native features.

### 2. Save does not overwrite the original file on disk

No browser API allows a web page or extension to silently write to an arbitrary file on disk. "Save" means: the extension produces a new PDF (via pdf-lib) and hands it to Edge's download system using the original filename with `saveAs: false`.

Whether Edge overwrites the existing file, creates a new one, or appends "(1)" depends entirely on **Edge's own download settings** — specifically whether "Ask where to save each file before downloading" is on or off, and whether a file with that name already exists in your Downloads folder. The extension does not control this behaviour.

**Workaround:** Set Edge's download folder to the same location as your original PDF, and turn off "Ask where to save" in Edge settings. Edge will then overwrite the file automatically.

### 3. Auto-interception is disabled by design

This extension is configured for **manual activation** only. You must click the extension icon to open the editor. This preserves normal PDF viewing in Edge's native viewer and lets you choose when to edit.

### 4. file:// PDFs require extra permission

To edit PDFs from your local disk, you must enable "Allow access to file URLs" for this extension in edge://extensions > Details. This is an Edge security requirement and cannot be bypassed.

### 5. Performance ceiling on very large files

Because everything runs client-side in the browser tab, extremely large PDFs (hundreds of pages, hundreds of MB) may hit browser memory limits. This is a fundamental limit of client-side processing, not a fixable bug. The extension uses virtualised rendering (only renders pages near the viewport) to mitigate this as much as possible.

---

## Non-Goals (also stated in README per spec §18)

- True in-place overwrite of the original file on disk
- Editing inside Edge's native/internal PDF viewer
- Any server-side, cloud, or account-based functionality
