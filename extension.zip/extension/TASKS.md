Last worked on: Full initial build — all modules written, icon generation pending.

---

## 0. Ground Rules
- [x] Architecture: viewer-owned PDF.js viewer, no native-viewer overlay
- [x] Manual activation only — icon click opens editor (no auto-interception)
- [x] Save = chrome.downloads.download() with original filename, saveAs: false
- [x] After save, editor tab closes (user preference)

## 2. PDF Detection & Entry
- [x] Popup detects if current tab URL ends in .pdf
- [x] Popup shows "Open in Editor" button on PDF pages
- [x] Popup shows "Not a PDF page" on non-PDF pages
- [x] Popup shows "Editor is active" when already in viewer
- [x] Background service worker navigates tab to viewer.html?src=<encoded-url>
- [x] Viewer parses ?src= param and fetches PDF bytes
- [ ] Content-Type header sniffing (http/https PDFs served without .pdf extension) — not implemented in v1 (no declarativeNetRequest); popup only detects by URL extension

## 3. Editing Layer
- [x] PDF.js renders each page to a <canvas>
- [x] Fabric.js canvas sits exactly on top of each page canvas
- [x] Virtualized rendering via IntersectionObserver (viewport ± 1200px buffer)
- [x] On zoom: re-render PDF.js at new scale + resize Fabric canvas proportionally
- [x] Per-page Fabric canvas (images keyed by page index, no cross-page leakage)
- [x] Serialise/deserialise Fabric state when page leaves/enters viewport

## 4. Floating Toolbar
- [x] Draggable via drag handle (mouse events)
- [x] Dark theme, glassmorphism, rounded corners
- [x] All actions present: Add Image, Undo, Redo, Delete, Duplicate,
      Bring Forward, Send Backward, Rotate Left, Rotate Right,
      Flip H, Flip V, Opacity slider, Lock/Unlock, Reset, Save PDF, Cancel
- [x] Self-contained SVG icon set (no external font or CDN)

## 5. Add Image / Image Manipulation
- [x] Formats: PNG, JPG/JPEG, WEBP, SVG
- [x] Multi-file selection; each becomes its own Fabric object
- [x] Per-image: drag, resize (Fabric default = aspect-locked), rotate, scale,
      delete, duplicate, move
- [x] Keyboard: Delete removes, Ctrl+C/V handled by Fabric internally,
      Ctrl+D duplicate, Ctrl+Z undo, Ctrl+Shift+Z redo, Ctrl+S save
- [x] Ctrl+Drag = duplicate-drag
- [x] Mouse-wheel rotate on selected image
- [x] Snapping: page edges, center, with guide lines (SnapGuides module)
- [x] Snap to corners — included in SnapGuides edge targets
- [ ] Group multi-select marquee transform — Fabric default selection handles this; no explicit grouping API call beyond canvas selection
- [x] Multi-select via shift-click (Fabric built-in)
- [x] Arrow-key nudge (Shift = 10px step, normal = 1px)
- [x] Fabric selection handles + bounding box styled by Fabric

## 6. Image Quality
- [x] Original bytes read as ArrayBuffer, stored alongside Fabric object
- [x] PNG/JPG embedded losslessly via pdf-lib embedPng/embedJpg
- [x] SVG rasterised to PNG at 300 DPI before embedding (pdf-lib limitation, documented)
- [x] WebP converted to PNG before embedding (pdf-lib limitation)
- [x] No intermediate lossy re-encode for PNG/JPG

## 7. Undo/Redo
- [x] Linear history stack (command pattern) in history.js
- [x] push(command), undo(), redo()
- [x] Per-session, unbounded (bounded by memory only; practical cap ~thousands of steps)
- [x] History cleared on document close

## 8. Save System
- [x] Load ORIGINAL PDF bytes into pdf-lib (not re-render)
- [x] For each page with images: embed images at correct page-relative coords
- [x] Coordinate transform: Fabric px → PDF points with y-flip and rotation
- [x] Rotation around image centre (adjusted anchor point calculation)
- [x] Opacity applied via pdf-lib drawImage options
- [x] Output filename = original filename, no suffix
- [x] chrome.downloads.download() with saveAs: false
- [x] Tab closes after download triggered

## 9. Performance
- [x] Virtualised rendering (IntersectionObserver, 1200px buffer)
- [x] Fabric canvas disposed + serialised when page leaves viewport
- [x] PDF canvas pixels cleared when off-screen
- [x] Render tasks cancelled when page scrolls away

## 10. Error Handling
- [x] Corrupted PDF → friendly error overlay
- [x] Password-protected PDF → prompt() for password
- [x] Unsupported image format → alert and skip
- [x] Oversized image → confirm dialog before adding
- [x] Save failure → alert with error message
- [x] fetch() failure → friendly error overlay with file:// tip

## 11. UI Design
- [x] Dark mode throughout
- [x] Glassmorphism toolbar
- [x] Rounded corners, shadows
- [x] Viewer header with zoom controls
- [x] Loading overlay with spinner
- [x] Error overlay

## 12. Architecture
- [x] Manifest V3
- [x] Background service worker (background.js)
- [x] Viewer page (viewer.html + ES module JS)
- [x] Action popup (popup.html / popup.js / popup.css)
- [x] ES modules for all custom code
- [x] UMD globals for vendored libs (fabric.min.js, pdf-lib.min.js)

## 13. Libraries (vendored locally)
- [x] PDF.js 4.4.168 (lib/pdf.mjs + lib/pdf.worker.mjs)
- [x] Fabric.js 6.4.0 (lib/fabric.min.js)
- [x] pdf-lib 1.17.1 (lib/pdf-lib.min.js)

## 14. Code Quality
- [x] Modular file layout (one concern per file)
- [x] JSDoc comments on non-trivial functions
- [x] Consistent error logging (console.error with context)
- [x] No jQuery, no global variables in custom code

## 15. Security
- [x] Fully offline — no external network calls
- [x] No analytics, telemetry, external servers
- [x] No remote code (Manifest V3 enforces this)

## 16. Deliverables
- [x] manifest.json (MV3)
- [x] background.js (service worker)
- [x] viewer.html / viewer.css / js/viewer.js
- [x] js/pdfRenderer.js, js/fabricOverlay.js, js/toolbar.js,
      js/history.js, js/saveManager.js, js/snapGuides.js
- [x] popup.html / popup.css / popup.js
- [x] lib/ — all three libraries vendored
- [x] icons/icon{16,48,128}.png — generated via generate-icons.js
- [x] README.md
- [x] TASKS.md

## 17. Known deferred / cut items (per Ground Rules priority order)
- [ ] SVG image support in Fabric — SVG is ACCEPTED as input but rasterised to PNG before PDF embedding (pdf-lib limitation). Fabric renders SVG inline fine.
- [ ] Group multi-select transform — Fabric's built-in activeSelection handles it; no additional code written
- [ ] Mouse-wheel rotate — IMPLEMENTED via fabric mouse:wheel event
- [ ] Snap-to-corners — IMPLEMENTED in SnapGuides via edge targets
