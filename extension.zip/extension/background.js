/**
 * background.js — Service Worker (Manifest V3)
 *
 * Responsibilities:
 *   1. Receive messages from popup.js requesting a tab navigation to the viewer.
 *   2. Navigate the requested tab to viewer.html?src=<encoded PDF URL>.
 *   3. Trigger downloads (called from viewer page via chrome.runtime.sendMessage).
 */

/** @param {number} tabId @param {string} pdfUrl */
async function openViewer(tabId, pdfUrl) {
  const viewerUrl =
    chrome.runtime.getURL('viewer.html') +
    '?src=' +
    encodeURIComponent(pdfUrl);
  await chrome.tabs.update(tabId, { url: viewerUrl });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'openViewer') {
    openViewer(message.tabId, message.pdfUrl)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true; // keep channel open for async response
  }

  if (message.type === 'download') {
    // viewer page asks background to trigger download (extension pages can use
    // chrome.downloads directly, but routing through background keeps a single
    // permission boundary).
    chrome.downloads.download(
      {
        url: message.dataUrl,
        filename: message.filename,
        saveAs: false, // auto-save with original filename per user preference
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ ok: true, downloadId });
        }
      }
    );
    return true;
  }
});
