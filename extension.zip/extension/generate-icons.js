/**
 * generate-icons.js — Creates icons/icon{16,48,128}.png using only Node.js
 * built-in modules (no external deps). Run once: node generate-icons.js
 *
 * Produces a simple layered icon: blue rounded-rect background + white PDF doc
 * silhouette + green check-circle. Good enough for a real extension icon.
 */
const zlib = require('zlib');
const fs   = require('fs');
const path = require('path');

// ─── CRC32 ───────────────────────────────────────────────────────────────────
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) crc = CRC_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

// ─── PNG helpers ─────────────────────────────────────────────────────────────
function u32(n) {
  const b = Buffer.alloc(4);
  b.writeUInt32BE(n >>> 0, 0);
  return b;
}

function pngChunk(type, data) {
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = crc32(Buffer.concat([typeBuf, data]));
  return Buffer.concat([u32(data.length), typeBuf, data, u32(crc)]);
}

/**
 * Build a PNG from a pixel function.
 * @param {number}   size  Width = height (square icon)
 * @param {function(x:number,y:number):[number,number,number,number]} pixelFn  → [r,g,b,a]
 */
function buildPng(size, pixelFn) {
  // IHDR: width, height, 8-bit RGBA
  const ihdr = Buffer.concat([u32(size), u32(size),
    Buffer.from([8, 6, 0, 0, 0])]);

  // Raw scanlines with filter byte 0 per row
  const rows = [];
  for (let y = 0; y < size; y++) {
    const row = Buffer.alloc(1 + size * 4);
    row[0] = 0; // filter: None
    for (let x = 0; x < size; x++) {
      const [r, g, b, a] = pixelFn(x, y);
      const i = 1 + x * 4;
      row[i]   = r; row[i+1] = g; row[i+2] = b; row[i+3] = a;
    }
    rows.push(row);
  }
  const raw  = Buffer.concat(rows);
  const comp = zlib.deflateSync(raw, { level: 9 });

  const sig  = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  return Buffer.concat([
    sig,
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', comp),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

// ─── Icon drawing ─────────────────────────────────────────────────────────────
/**
 * Smooth step for anti-aliasing (value 0 outside circle, 1 inside).
 * @param {number} dx @param {number} dy @param {number} r @returns {number}
 */
function circleMask(dx, dy, r) {
  const d = Math.sqrt(dx * dx + dy * dy);
  return Math.max(0, Math.min(1, (r + 0.5 - d)));
}

function roundRectMask(x, y, w, h, r, cx, cy) {
  // Signed distance from rounded rect
  const dx = Math.max(0, Math.abs(x - cx) - w / 2 + r);
  const dy = Math.max(0, Math.abs(y - cy) - h / 2 + r);
  const d  = Math.sqrt(dx * dx + dy * dy) - r;
  return Math.max(0, Math.min(1, -d + 0.5));
}

function lerp(a, b, t) { return a + (b - a) * t; }
function lerpC(c1, c2, t) {
  return [lerp(c1[0],c2[0],t), lerp(c1[1],c2[1],t), lerp(c1[2],c2[2],t), lerp(c1[3],c2[3],t)];
}
function blend(bg, fg) {
  const a = fg[3] / 255;
  return [
    Math.round(lerp(bg[0], fg[0], a)),
    Math.round(lerp(bg[1], fg[1], a)),
    Math.round(lerp(bg[2], fg[2], a)),
    Math.max(bg[3], Math.round(fg[3])),
  ];
}

function makeIconPixel(x, y, S) {
  const cx = S / 2, cy = S / 2;
  const pad = S * 0.04;
  const rr  = S * 0.18; // rounded-rect corner radius

  // Background colour: blue (#4F8EF7)
  const bgColor = [79, 142, 247];

  // Rounded background rect
  const bgMask = roundRectMask(x, y, S - pad * 2, S - pad * 2, rr, cx, cy);
  if (bgMask <= 0) return [0, 0, 0, 0]; // transparent outside

  // ─── PDF doc shape (white) ──────────────────────────────────────────
  const docX  = cx - S * 0.12;   // doc centre-x
  const docY  = cy - S * 0.05;
  const docW  = S * 0.38;
  const docH  = S * 0.50;
  const foldS = S * 0.12;        // fold (dog-ear) size

  // Simple rectangle doc, clipped to fold corner
  let docMask = 0;
  const rx = Math.abs(x - docX), ry = Math.abs(y - docY);
  if (rx < docW / 2 && ry < docH / 2) {
    // Fold: top-right corner
    const foldX = docX + docW / 2 - foldS;
    const foldY = docY - docH / 2 + foldS;
    if (x > foldX && y < foldY) {
      // inside fold-cut area: not part of doc
      docMask = 0;
    } else {
      docMask = 1;
    }
  }

  // ─── Green check circle (bottom-right) ─────────────────────────────
  const circR  = S * 0.22;
  const circCX = cx + S * 0.22;
  const circCY = cy + S * 0.22;
  const circMask = circleMask(x - circCX, y - circCY, circR);

  // ─── Compose ─────────────────────────────────────────────────────────
  let [r, g, b] = bgColor;
  let a = Math.round(bgMask * 255);

  if (docMask > 0) {
    const t = docMask;
    r = Math.round(lerp(r, 255, t));
    g = Math.round(lerp(g, 255, t));
    b = Math.round(lerp(b, 255, t));
  }

  if (circMask > 0) {
    // Green circle overlays everything
    r = Math.round(lerp(r, 52,  circMask));
    g = Math.round(lerp(g, 201, circMask));
    b = Math.round(lerp(b, 122, circMask));
  }

  // Check mark on the green circle (white, simplified as a bright region)
  if (circMask > 0) {
    // Simple white tick lines
    const lx = x - circCX, ly = y - circCY;
    // Tick: from (-r*0.45, 0) → (−r*0.1, r*0.35) → (r*0.45, −r*0.4)
    const tickWidth = S * 0.03;
    // Segment 1: left-bottom diagonal
    const seg1 = lineSegDist(lx, ly, -circR*0.45, circR*0.0, -circR*0.1, circR*0.35);
    const seg2 = lineSegDist(lx, ly, -circR*0.1, circR*0.35,  circR*0.45, -circR*0.35);
    const tickMask = Math.max(
      Math.max(0, 1 - seg1 / tickWidth),
      Math.max(0, 1 - seg2 / tickWidth),
    ) * circMask;
    if (tickMask > 0) {
      r = Math.round(lerp(r, 255, tickMask));
      g = Math.round(lerp(g, 255, tickMask));
      b = Math.round(lerp(b, 255, tickMask));
    }
  }

  return [r, g, b, a];
}

/** Distance from point (px, py) to line segment (ax,ay)→(bx,by). */
function lineSegDist(px, py, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay;
  const len2 = dx * dx + dy * dy;
  if (len2 === 0) return Math.hypot(px - ax, py - ay);
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / len2));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}

// ─── Generate files ───────────────────────────────────────────────────────────
const outDir = path.join(__dirname, 'icons');
fs.mkdirSync(outDir, { recursive: true });

for (const size of [16, 48, 128]) {
  const buf = buildPng(size, (x, y) => makeIconPixel(x, y, size));
  fs.writeFileSync(path.join(outDir, `icon${size}.png`), buf);
  console.log(`✓ icons/icon${size}.png  (${buf.length} bytes)`);
}
console.log('Done.');
