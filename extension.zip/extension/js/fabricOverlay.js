/**
 * fabricOverlay.js — Fabric.js canvas overlay management.
 *
 * One FabricOverlay instance manages ALL pages' Fabric canvases.
 * Objects are stored in "natural" Fabric coordinates (at the base scale used
 * when the object was created). When zoom changes, setZoom() is called on the
 * active canvas so positions appear pixel-locked to the PDF beneath.
 *
 * Per-page data is serialised to JSON when a page leaves the viewport and
 * re-hydrated when it re-enters, so memory pressure stays low even for large
 * documents.
 */
import { SnapGuides } from './snapGuides.js';

/** Retrieve the fabric global (UMD loaded via <script> tag). */
function getFabric() {
  if (!window.fabric) throw new Error('Fabric.js not loaded');
  return window.fabric;
}

/** Unique ID generator for image objects. */
let _nextId = 1;
function nextId() { return 'img_' + (_nextId++); }

export class FabricOverlay {
  constructor({ onSelectionChange, onModified, history }) {
    /**
     * @type {Map<number, {
     *   canvas: fabric.Canvas | null,
     *   canvasEl: HTMLCanvasElement | null,
     *   json: object | null,           // serialised state when off-screen
     *   naturalW: number,              // page width at scale=1
     *   naturalH: number,
     *   currentScale: number,
     *   imageData: Map<string, {dataUrl: string, format: string, bytes: ArrayBuffer}>,
     *   snap: SnapGuides | null,
     *   pageContainer: HTMLElement | null,
     * }>}
     */
    this._pages = new Map();
    this._onSelectionChange = onSelectionChange || (() => {});
    this._onModified = onModified || (() => {});
    this._history = history;
  }

  // ---------------------------------------------------------------------------
  // Page lifecycle
  // ---------------------------------------------------------------------------

  /**
   * Register a page so the overlay knows its natural dimensions.
   * Must be called before renderPage for each page number.
   */
  registerPage(pageNum, naturalW, naturalH) {
    if (!this._pages.has(pageNum)) {
      this._pages.set(pageNum, {
        canvas: null,
        canvasEl: null,
        json: null,
        naturalW,
        naturalH,
        currentScale: 1,
        imageData: new Map(),
        snap: null,
        pageContainer: null,
      });
    } else {
      const p = this._pages.get(pageNum);
      p.naturalW = naturalW;
      p.naturalH = naturalH;
    }
  }

  /**
   * Attach a Fabric canvas to a page container.
   * Called when the page enters the viewport (or on first render).
   *
   * @param {number}      pageNum
   * @param {HTMLElement} pageContainer  The wrapper div for this page.
   * @param {number}      scale          Current render scale.
   */
  async attachPage(pageNum, pageContainer, scale) {
    const fabric = getFabric();
    const p = this._pages.get(pageNum);
    if (!p) throw new Error('Page not registered: ' + pageNum);

    // If a canvas already exists for this page, just resize/zoom it
    if (p.canvas) {
      await this._resizeCanvas(pageNum, scale);
      return;
    }

    const w = Math.round(p.naturalW * scale);
    const h = Math.round(p.naturalH * scale);

    // Create the <canvas> element the Fabric canvas will wrap
    const el = document.createElement('canvas');
    el.className = 'fabric-canvas';
    el.width = w;
    el.height = h;
    el.style.width = w + 'px';
    el.style.height = h + 'px';
    pageContainer.appendChild(el);

    const fc = new fabric.Canvas(el, {
      selection: true,
      preserveObjectStacking: true,
    });
    fc.setDimensions({ width: w, height: h });

    // Fabric wraps the <canvas> in a .canvas-container div and sets it to
    // position:relative. We need it absolutely positioned over the PDF canvas.
    // The CSS rule `.page-wrapper .canvas-container` handles this, but we also
    // set it inline as a safety measure in case Fabric reinjects its own style.
    const containerEl = el.parentElement;
    if (containerEl && containerEl.classList.contains('canvas-container')) {
      containerEl.style.position = 'absolute';
      containerEl.style.top  = '0';
      containerEl.style.left = '0';
      containerEl.style.zIndex = '2';
    }

    p.canvas = fc;
    p.canvasEl = el;
    p.currentScale = scale;
    p.pageContainer = pageContainer;
    p.snap = new SnapGuides(pageContainer, w, h);

    // Re-hydrate serialised state if any
    if (p.json) {
      await this._loadJson(pageNum, p.json);
      p.json = null;
    }

    this._bindEvents(pageNum);
  }

  /**
   * Detach a page's Fabric canvas (called when it scrolls far off-screen).
   * Serialises current state to JSON so it can be restored later.
   */
  detachPage(pageNum) {
    const p = this._pages.get(pageNum);
    if (!p || !p.canvas) return;

    p.json = p.canvas.toJSON(['id', 'locked']);
    p.snap?.clearGuides();
    p.canvas.dispose();
    p.canvas = null;
    // The canvas element is removed automatically when the parent is cleared
    p.canvasEl = null;
    p.pageContainer = null;
    p.snap = null;
  }

  /**
   * Update scale for an already-attached page (e.g. after zoom).
   */
  async _resizeCanvas(pageNum, scale) {
    const p = this._pages.get(pageNum);
    if (!p?.canvas) return;
    const w = Math.round(p.naturalW * scale);
    const h = Math.round(p.naturalH * scale);
    const ratio = scale / p.currentScale;

    // Scale all object positions/dimensions proportionally
    const objects = p.canvas.getObjects();
    for (const obj of objects) {
      obj.set({
        left:   obj.left   * ratio,
        top:    obj.top    * ratio,
        scaleX: obj.scaleX * ratio,
        scaleY: obj.scaleY * ratio,
      });
      obj.setCoords();
    }

    p.canvas.setDimensions({ width: w, height: h });
    p.canvasEl.style.width  = w + 'px';
    p.canvasEl.style.height = h + 'px';
    p.currentScale = scale;
    p.snap?.resize(w, h);
    p.canvas.renderAll();
  }

  /**
   * Update scale on ALL attached pages simultaneously (global zoom change).
   * For detached pages we transform the stored JSON coordinates so that when
   * they are re-attached at the new scale the positions are still correct.
   */
  async setScale(newScale) {
    for (const [pageNum] of this._pages) {
      const p = this._pages.get(pageNum);
      if (p.canvas) {
        await this._resizeCanvas(pageNum, newScale);
      } else {
        if (p.json && p.currentScale !== newScale) {
          // Rescale object positions stored in JSON from old scale → new scale
          const ratio = newScale / p.currentScale;
          for (const obj of (p.json.objects ?? [])) {
            if (typeof obj.left   === 'number') obj.left   *= ratio;
            if (typeof obj.top    === 'number') obj.top    *= ratio;
            if (typeof obj.scaleX === 'number') obj.scaleX *= ratio;
            if (typeof obj.scaleY === 'number') obj.scaleY *= ratio;
          }
        }
        p.currentScale = newScale;
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Image operations
  // ---------------------------------------------------------------------------

  /**
   * Add an image to a page's Fabric canvas.
   * @param {number} pageNum
   * @param {string} dataUrl   Data URL of the image.
   * @param {string} format    'png'|'jpg'|'webp'|'svg'
   * @param {ArrayBuffer} bytes  Original raw bytes for lossless embedding.
   */
  async addImage(pageNum, dataUrl, format, bytes) {
    const fabric = getFabric();
    const p = this._pages.get(pageNum);
    if (!p?.canvas) throw new Error('Canvas not attached for page ' + pageNum);

    const id = nextId();

    // Load into Fabric
    const imgCtor = fabric.FabricImage ?? fabric.Image;
    const fabImg = await imgCtor.fromURL(dataUrl, { crossOrigin: null });

    const canvasW = p.canvas.getWidth();
    const canvasH = p.canvas.getHeight();

    // Center on the visible canvas, scale down if image is larger than page
    let scaleX = 1;
    let scaleY = 1;
    const maxW = canvasW * 0.8;
    const maxH = canvasH * 0.8;
    if (fabImg.width > maxW || fabImg.height > maxH) {
      const sX = maxW / fabImg.width;
      const sY = maxH / fabImg.height;
      const s = Math.min(sX, sY);
      scaleX = s;
      scaleY = s;
    }

    fabImg.set({
      id,
      left:    canvasW / 2 - (fabImg.width * scaleX) / 2,
      top:     canvasH / 2 - (fabImg.height * scaleY) / 2,
      scaleX,
      scaleY,
      opacity: 1,
      locked:  false,
    });

    // Store original bytes keyed by id for lossless PDF embedding
    p.imageData.set(id, { dataUrl, format, bytes });

    // History command
    if (this._history) {
      this._history.push({
        execute: () => {
          p.canvas.add(fabImg);
          p.canvas.setActiveObject(fabImg);
          p.canvas.renderAll();
        },
        undo: () => {
          p.canvas.remove(fabImg);
          p.canvas.discardActiveObject();
          p.canvas.renderAll();
        },
      });
    } else {
      p.canvas.add(fabImg);
      p.canvas.setActiveObject(fabImg);
      p.canvas.renderAll();
    }

    return id;
  }

  /** Delete the currently selected object(s) on a page. */
  deleteSelected(pageNum) {
    const p = this._pages.get(pageNum);
    if (!p?.canvas) return;
    const active = p.canvas.getActiveObject();
    if (!active) return;

    const toRemove = active.type === 'activeselection'
      ? active.getObjects()
      : [active];

    if (this._history) {
      this._history.push({
        execute: () => {
          for (const obj of toRemove) {
            p.canvas.remove(obj);
          }
          p.canvas.discardActiveObject();
          p.canvas.renderAll();
        },
        undo: () => {
          for (const obj of toRemove) p.canvas.add(obj);
          p.canvas.renderAll();
        },
      });
    } else {
      for (const obj of toRemove) p.canvas.remove(obj);
      p.canvas.discardActiveObject();
      p.canvas.renderAll();
    }
  }

  /** Duplicate the currently selected object. */
  async duplicateSelected(pageNum) {
    const fabric = getFabric();
    const p = this._pages.get(pageNum);
    if (!p?.canvas) return;
    const active = p.canvas.getActiveObject();
    if (!active) return;

    const clone = await active.clone(['id', 'locked']);
    const newId = nextId();
    clone.set({ id: newId, left: clone.left + 20, top: clone.top + 20 });

    // Copy imageData entry
    const oldId = active.get('id');
    if (p.imageData.has(oldId)) {
      p.imageData.set(newId, { ...p.imageData.get(oldId) });
    }

    if (this._history) {
      this._history.push({
        execute: () => {
          p.canvas.add(clone);
          p.canvas.setActiveObject(clone);
          p.canvas.renderAll();
        },
        undo: () => {
          p.canvas.remove(clone);
          p.canvas.discardActiveObject();
          p.canvas.renderAll();
        },
      });
    } else {
      p.canvas.add(clone);
      p.canvas.setActiveObject(clone);
      p.canvas.renderAll();
    }
  }

  /** Bring selected object one step forward in z-order. */
  bringForward(pageNum) {
    const p = this._pages.get(pageNum);
    const active = p?.canvas?.getActiveObject();
    if (!active) return;
    p.canvas.bringObjectForward(active);
    p.canvas.renderAll();
  }

  /** Send selected object one step backward in z-order. */
  sendBackward(pageNum) {
    const p = this._pages.get(pageNum);
    const active = p?.canvas?.getActiveObject();
    if (!active) return;
    p.canvas.sendObjectBackwards(active);
    p.canvas.renderAll();
  }

  /** Rotate selected object by `degrees` (positive = clockwise). */
  rotateSelected(pageNum, degrees) {
    const p = this._pages.get(pageNum);
    const active = p?.canvas?.getActiveObject();
    if (!active) return;
    const prev = active.angle;
    if (this._history) {
      this._history.push({
        execute: () => { active.rotate((prev + degrees) % 360); p.canvas.renderAll(); },
        undo:    () => { active.rotate(prev);                    p.canvas.renderAll(); },
      });
    } else {
      active.rotate((active.angle + degrees) % 360);
      p.canvas.renderAll();
    }
  }

  /** Flip selected object horizontally. */
  flipHorizontal(pageNum) {
    const p = this._pages.get(pageNum);
    const active = p?.canvas?.getActiveObject();
    if (!active) return;
    active.set('flipX', !active.flipX);
    p.canvas.renderAll();
  }

  /** Flip selected object vertically. */
  flipVertical(pageNum) {
    const p = this._pages.get(pageNum);
    const active = p?.canvas?.getActiveObject();
    if (!active) return;
    active.set('flipY', !active.flipY);
    p.canvas.renderAll();
  }

  /** Set opacity of selected object (0–1). */
  setOpacity(pageNum, value) {
    const p = this._pages.get(pageNum);
    const active = p?.canvas?.getActiveObject();
    if (!active) return;
    active.set('opacity', value);
    p.canvas.renderAll();
  }

  /** Lock/unlock the selected object (prevent dragging/resizing). */
  toggleLock(pageNum) {
    const p = this._pages.get(pageNum);
    const active = p?.canvas?.getActiveObject();
    if (!active) return;
    const locked = !active.get('locked');
    active.set({
      locked,
      selectable:   !locked,
      evented:       !locked,
      lockMovementX: locked,
      lockMovementY: locked,
      lockRotation:  locked,
      lockScalingX:  locked,
      lockScalingY:  locked,
    });
    p.canvas.renderAll();
    return locked;
  }

  /** Remove all images from the given page. */
  resetPage(pageNum) {
    const p = this._pages.get(pageNum);
    if (!p?.canvas) return;
    const all = [...p.canvas.getObjects()];
    if (all.length === 0) return;
    if (this._history) {
      this._history.push({
        execute: () => { p.canvas.clear(); p.canvas.renderAll(); },
        undo:    () => { for (const o of all) p.canvas.add(o); p.canvas.renderAll(); },
      });
    } else {
      p.canvas.clear();
    }
  }

  /** Get the selected object on a page (null if none). */
  getSelected(pageNum) {
    const p = this._pages.get(pageNum);
    return p?.canvas?.getActiveObject() ?? null;
  }

  /**
   * Collect all image data for every page, for the save pipeline.
   * Returns a Map<pageNum, Array<ImageRecord>> where ImageRecord has:
   *   { left, top, scaleX, scaleY, width, height, angle, opacity, flipX, flipY,
   *     format, bytes, dataUrl }
   * All coordinates are in current canvas pixels (at the current scale).
   * The save manager will convert them to PDF point space.
   */
  getAllImageData() {
    const result = new Map();
    for (const [pageNum, p] of this._pages) {
      const objects = p.canvas
        ? p.canvas.getObjects()
        : (p.json?.objects ?? []).filter(o => o.type === 'image');

      if (objects.length === 0) continue;

      const scale = p.currentScale;
      const records = [];

      for (const obj of objects) {
        // For live canvas objects, read directly from Fabric
        // For serialised JSON objects, read from JSON properties
        const isLive = !!p.canvas;
        const id = isLive ? obj.get('id') : obj.id;
        const imgMeta = p.imageData.get(id) ?? { format: 'png', bytes: null, dataUrl: '' };

        records.push({
          // Fabric canvas pixels at current render scale
          left:   isLive ? obj.left   : obj.left,
          top:    isLive ? obj.top    : obj.top,
          scaleX: isLive ? obj.scaleX : obj.scaleX,
          scaleY: isLive ? obj.scaleY : obj.scaleY,
          width:  isLive ? obj.width  : obj.width,
          height: isLive ? obj.height : obj.height,
          angle:  isLive ? obj.angle  : obj.angle,
          opacity: isLive ? obj.opacity : obj.opacity,
          flipX:  isLive ? obj.flipX  : (obj.flipX ?? false),
          flipY:  isLive ? obj.flipY  : (obj.flipY ?? false),
          renderScale: scale,
          naturalW: p.naturalW,
          naturalH: p.naturalH,
          format: imgMeta.format,
          bytes:  imgMeta.bytes,
          dataUrl: imgMeta.dataUrl,
        });
      }

      if (records.length > 0) result.set(pageNum, records);
    }
    return result;
  }

  // ---------------------------------------------------------------------------
  // Internal helpers
  // ---------------------------------------------------------------------------

  _bindEvents(pageNum) {
    const p = this._pages.get(pageNum);
    const fc = p.canvas;
    if (!fc) return;

    fc.on('selection:created', () => this._onSelectionChange(pageNum, fc.getActiveObject()));
    fc.on('selection:updated', () => this._onSelectionChange(pageNum, fc.getActiveObject()));
    fc.on('selection:cleared', () => this._onSelectionChange(pageNum, null));

    fc.on('object:modified', () => this._onModified(pageNum));

    // Snap on move
    fc.on('object:moving', (e) => {
      const obj = e.target;
      if (!p.snap) return;
      const w = obj.getScaledWidth();
      const h = obj.getScaledHeight();
      const { x, y } = p.snap.snap(obj.left, obj.top, w, h);
      obj.set({ left: x, top: y });
    });

    fc.on('object:moved', () => p.snap?.clearGuides());

    // Ctrl+drag = duplicate-drag
    fc.on('mouse:down', (e) => {
      if (e.e.ctrlKey && fc.getActiveObject()) {
        fc.getActiveObject()?.clone(['id', 'locked']).then(async (clone) => {
          const newId = nextId();
          clone.set({ id: newId });
          const src = fc.getActiveObject()?.get('id');
          if (src && p.imageData.has(src)) p.imageData.set(newId, { ...p.imageData.get(src) });
          fc.add(clone);
          fc.setActiveObject(clone);
        });
      }
    });

    // Mouse-wheel rotate on selected object
    fc.on('mouse:wheel', (e) => {
      const obj = fc.getActiveObject();
      if (!obj) return;
      const delta = e.e.deltaY;
      obj.rotate((obj.angle + (delta > 0 ? 3 : -3)) % 360);
      fc.renderAll();
      e.e.preventDefault();
    });
  }

  async _loadJson(pageNum, json) {
    const p = this._pages.get(pageNum);
    if (!p?.canvas) return;
    return new Promise((resolve) => {
      p.canvas.loadFromJSON(json, () => {
        p.canvas.renderAll();
        resolve();
      });
    });
  }
}
