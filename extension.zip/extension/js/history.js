/**
 * history.js — Undo/Redo command stack (command pattern).
 *
 * Each command must have:
 *   { execute(): void, undo(): void }
 *
 * The stack is unbounded per session; memory usage is bounded only by the
 * number of image objects the user creates. In practice, thousands of steps
 * are fine. If memory becomes a concern in extremely large sessions, consider
 * capping at ~2000 entries and dropping the oldest (would break undo past
 * that point — document if ever implemented).
 */
export class History {
  constructor() {
    /** @type {Array<{execute: Function, undo: Function}>} */
    this._stack = [];
    /** @type {number} Current position in the stack (-1 = empty). */
    this._cursor = -1;
    /** @type {Function[]} Listeners called whenever stack state changes. */
    this._listeners = [];
  }

  /** Register a callback fired on every push/undo/redo so UI can update. */
  onChange(fn) {
    this._listeners.push(fn);
  }

  _notify() {
    for (const fn of this._listeners) fn({ canUndo: this.canUndo, canRedo: this.canRedo });
  }

  /** Execute a command and push it onto the stack. Discards any redo history. */
  push(command) {
    // Discard everything after the current cursor (branching history not supported)
    this._stack.splice(this._cursor + 1);
    command.execute();
    this._stack.push(command);
    this._cursor = this._stack.length - 1;
    this._notify();
  }

  /** Undo the last command, if any. */
  undo() {
    if (!this.canUndo) return;
    this._stack[this._cursor].undo();
    this._cursor--;
    this._notify();
  }

  /** Redo the next command, if any. */
  redo() {
    if (!this.canRedo) return;
    this._cursor++;
    this._stack[this._cursor].execute();
    this._notify();
  }

  get canUndo() { return this._cursor >= 0; }
  get canRedo() { return this._cursor < this._stack.length - 1; }

  /** Wipe the history (e.g. on document close or reset). */
  clear() {
    this._stack = [];
    this._cursor = -1;
    this._notify();
  }
}
