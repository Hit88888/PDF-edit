/**
 * pdfRenderer.js — PDF.js rendering layer.
 *
 * Manages:
 *   - Loading a PDF document from a URL or ArrayBuffer.
 *   - Rendering individual pages to <canvas> elements at a given scale.
 *   - Cancelling in-flight renders when a page leaves the viewport.
 *   - Password-protected PDF prompting.
 */

// PDF.js is imported as an ES module (vendored at lib/pdf.mjs).
// The worker URL must point to the extension's local copy so it loads from
// chrome-extension:// and is not blocked by CSP.
let pdfjsLib = null;

export async function initPdfJs() {
  if (pdfjsLib) return pdfjsLib;
  pdfjsLib = await import(chrome.runtime.getURL('lib/pdf.mjs'));
  pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('lib/pdf.worker.mjs');
  return pdfjsLib;
}

export class PdfRenderer {
  constructor() {
    /** @type {import('pdfjs-dist').PDFDocumentProxy | null} */
    this._doc = null;
    /** @type {Map<number, import('pdfjs-dist').RenderTask>} active render tasks keyed by pageNum */
    this._renderTasks = new Map();
    /** @type {number} Total number of pages. */
    this.numPages = 0;
    /** @type {string} Original PDF source URL. */
    this.sourceUrl = '';
    /** @type {ArrayBuffer | null} Original PDF bytes — kept for save pipeline. */
    this.originalBytes = null;
  }

  /**
   * Load a PDF from a URL. Fetches bytes, stores them, and opens the document.
   * Returns true on success; throws on error.
   *
   * @param {string}          url           The original PDF URL (http/https/file/blob).
   * @param {function():string} [askPassword] Called when doc is password-protected.
   *   Should return a Promise<string> with the password entered by the user.
   */
  async load(url, askPassword) {
    await initPdfJs();
    this.sourceUrl = url;

    // Fetch the raw bytes so we have them for pdf-lib save later.
    let bytes;
    try {
      const resp = await fetch(url);
      if (!resp.ok) throw new Error(`Fetch failed: ${resp.status} ${resp.statusText}`);
      bytes = await resp.arrayBuffer();
    } catch (err) {
      throw new Error(`Could not fetch PDF: ${err.message}`);
    }
    this.originalBytes = bytes;

    // Open with PDF.js (use a copy since PDF.js may detach the buffer).
    const loadingTask = pdfjsLib.getDocument({
      data: bytes.slice(0),
      onPassword: askPassword
        ? (updatePassword, reason) => {
            const pw = askPassword(reason);
            if (pw instanceof Promise) pw.then(updatePassword);
            else updatePassword(pw);
          }
        : undefined,
    });

    this._doc = await loadingTask.promise;
    this.numPages = this._doc.numPages;
    return this._doc;
  }

  /**
   * Load a PDF from an existing ArrayBuffer (e.g. an already-fetched file).
   * Equivalent to load() but skips the fetch step.
   */
  async loadFromBuffer(buffer, sourceUrl = '') {
    await initPdfJs();
    this.sourceUrl = sourceUrl;
    this.originalBytes = buffer;
    const loadingTask = pdfjsLib.getDocument({ data: buffer.slice(0) });
    this._doc = await loadingTask.promise;
    this.numPages = this._doc.numPages;
    return this._doc;
  }

  /**
   * Get the natural viewport of a page at scale=1 (in CSS pixels).
   * @returns {Promise<{width: number, height: number}>}
   */
  async getPageNaturalSize(pageNum) {
    const page = await this._doc.getPage(pageNum);
    const vp = page.getViewport({ scale: 1 });
    return { width: vp.width, height: vp.height };
  }

  /**
   * Render a page onto the provided canvas element.
   * Cancels any prior in-flight render for the same page number.
   *
   * @param {number}            pageNum  1-based page number.
   * @param {HTMLCanvasElement} canvas   Target canvas (must already be in DOM).
   * @param {number}            scale    Render scale (1 = natural CSS size).
   * @returns {Promise<{width: number, height: number}>}  Pixel dimensions of the render.
   */
  async renderPage(pageNum, canvas, scale) {
    if (!this._doc) throw new Error('No PDF loaded');

    // Cancel any in-flight render for this page
    this.cancelRender(pageNum);

    const page = await this._doc.getPage(pageNum);
    const viewport = page.getViewport({ scale });

    // Size the canvas exactly
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(viewport.width * dpr);
    canvas.height = Math.floor(viewport.height * dpr);
    canvas.style.width = Math.floor(viewport.width) + 'px';
    canvas.style.height = Math.floor(viewport.height) + 'px';

    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const renderContext = { canvasContext: ctx, viewport };
    const task = page.render(renderContext);
    this._renderTasks.set(pageNum, task);

    try {
      await task.promise;
    } catch (err) {
      if (err?.name === 'RenderingCancelledException') return null; // normal cancellation
      throw err;
    } finally {
      this._renderTasks.delete(pageNum);
    }

    return {
      width: Math.floor(viewport.width),
      height: Math.floor(viewport.height),
    };
  }

  /**
   * Cancel an in-flight render for a page (e.g. when it scrolls off-screen).
   * Safe to call even if no render is active for that page.
   */
  cancelRender(pageNum) {
    const task = this._renderTasks.get(pageNum);
    if (task) {
      task.cancel();
      this._renderTasks.delete(pageNum);
    }
  }

  /** Cancel all in-flight renders. */
  cancelAll() {
    for (const task of this._renderTasks.values()) task.cancel();
    this._renderTasks.clear();
  }

  /** Destroy the document and free memory. */
  destroy() {
    this.cancelAll();
    if (this._doc) {
      this._doc.destroy();
      this._doc = null;
    }
    this.originalBytes = null;
  }
}
