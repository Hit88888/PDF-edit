/**
 * saveManager.js — Save pipeline using pdf-lib.
 *
 * Takes the original PDF bytes + per-page image records from FabricOverlay,
 * embeds the images losslessly into the correct pages, and triggers a download.
 *
 * Coordinate maths (critical — read before editing):
 * ─────────────────────────────────────────────────────
 * PDF space:  origin at bottom-left, x right, y up, units = points (pt).
 * Fabric/canvas space: origin top-left, x right, y down, units = px.
 *
 * Render scale `s` maps points → CSS pixels:  1 pt * s = s px.
 *   canvasWidth  = naturalWidth  * s   (where naturalWidth  = pageViewport(scale=1).width)
 *   canvasHeight = naturalHeight * s
 *
 * Pixel-to-point ratio:  pxToPt = 1 / s
 *
 * PDF.js's getViewport(scale=1) returns dimensions in CSS pixels at 96dpi,
 * which equals points (72pt/inch) × (96px/inch ÷ 72pt/inch) = 1.333… px/pt.
 * However, since we use the same viewport for both the canvas size and the
 * coordinate math, the ratio cancels and we only need `pxToPt = 1/s`.
 *
 * For a Fabric object at (obj.left, obj.top) with scaleX/Y and angle α° (CW):
 *   scaledW  = obj.width  * obj.scaleX  (in canvas px)
 *   scaledH  = obj.height * obj.scaleY
 *   centerFabricX = obj.left + scaledW / 2
 *   centerFabricY = obj.top  + scaledH / 2
 *
 *   centerPdfX = centerFabricX * pxToPt
 *   centerPdfY = pageHeightPt - centerFabricY * pxToPt   ← y flip
 *
 * pdf-lib drawImage rotates CCW around (x, y) = the image's bottom-left
 * anchor.  To rotate around the image's centre:
 *   θ = α × π/180   (α is CW Fabric angle → same angle is CCW in PDF y-up space)
 *   cosA = cos(θ),  sinA = sin(θ)
 *   x = centerPdfX - halfW*cosA - halfH*sinA
 *   y = centerPdfY - halfW*sinA - halfH*cosA    (verified with θ=0 and θ=90°)
 *   rotate argument: degrees(α)   [pdf-lib treats positive as CCW]
 *
 * SVG images are rasterised to PNG via an off-screen canvas before embedding
 * because pdf-lib has no native vector/SVG support.
 */

/** pdf-lib is loaded as a UMD script that sets window.PDFLib. */
function getPdfLib() {
  if (!window.PDFLib) throw new Error('pdf-lib not loaded');
  return window.PDFLib;
}

/**
 * Rasterise an SVG data-URL to a PNG ArrayBuffer at a fixed DPI.
 * @param {string} svgDataUrl
 * @param {number} [dpi=300]
 * @returns {Promise<ArrayBuffer>}
 */
async function rasteriseSvg(svgDataUrl, dpi = 300) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      // Render at target DPI (96 = screen DPI, scale accordingly)
      const scale = dpi / 96;
      const canvas = document.createElement('canvas');
      canvas.width  = Math.round(img.width  * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      canvas.toBlob((blob) => {
        if (!blob) { reject(new Error('SVG rasterisation failed')); return; }
        blob.arrayBuffer().then(resolve).catch(reject);
      }, 'image/png');
    };
    img.onerror = () => reject(new Error('Could not load SVG for rasterisation'));
    img.src = svgDataUrl;
  });
}

/**
 * Determine if bytes are PNG (by magic bytes: 0x89 P N G).
 * @param {ArrayBuffer} bytes
 * @returns {boolean}
 */
function isPng(bytes) {
  const v = new Uint8Array(bytes, 0, 4);
  return v[0] === 0x89 && v[1] === 0x50 && v[2] === 0x4e && v[3] === 0x47;
}

/**
 * Determine if bytes are JPEG (magic: 0xFF 0xD8).
 * @param {ArrayBuffer} bytes
 */
function isJpeg(bytes) {
  const v = new Uint8Array(bytes, 0, 2);
  return v[0] === 0xff && v[1] === 0xd8;
}

/**
 * Convert a PNG or JPEG ArrayBuffer to a data URL.
 * @param {ArrayBuffer} bytes
 * @param {'png'|'jpg'} format
 * @returns {string}
 */
function bytesToDataUrl(bytes, format) {
  const mime = format === 'jpg' ? 'image/jpeg' : 'image/png';
  let binary = '';
  const arr = new Uint8Array(bytes);
  for (let i = 0; i < arr.byteLength; i++) binary += String.fromCharCode(arr[i]);
  return `data:${mime};base64,${btoa(binary)}`;
}

/**
 * Re-encode a WebP data URL to PNG via canvas (pdf-lib supports only PNG/JPEG).
 * @param {string} webpDataUrl
 * @returns {Promise<ArrayBuffer>}
 */
async function webpToPng(webpDataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width  = img.naturalWidth;
      canvas.height = img.naturalHeight;
      canvas.getContext('2d').drawImage(img, 0, 0);
      canvas.toBlob((blob) => {
        if (!blob) { reject(new Error('WebP→PNG conversion failed')); return; }
        blob.arrayBuffer().then(resolve).catch(reject);
      }, 'image/png');
    };
    img.onerror = () => reject(new Error('Could not load WebP image'));
    img.src = webpDataUrl;
  });
}

/**
 * Main save function.
 *
 * @param {ArrayBuffer}       originalPdfBytes   Raw bytes from PdfRenderer.originalBytes.
 * @param {Map<number, Array>} pageImageData      From FabricOverlay.getAllImageData().
 * @param {string}            filename            Desired output filename.
 * @returns {Promise<void>}   Resolves when download is triggered.
 */
export async function savePdf(originalPdfBytes, pageImageData, filename) {
  const { PDFDocument, degrees } = getPdfLib();

  // Load the ORIGINAL document structure (not a re-render).
  // This preserves all text, vectors, hyperlinks, bookmarks, and metadata.
  const pdfDoc = await PDFDocument.load(new Uint8Array(originalPdfBytes), {
    ignoreEncryption: true,
  });

  const pages = pdfDoc.getPages();

  for (const [pageNum, records] of pageImageData) {
    const pageIndex = pageNum - 1; // 1-based → 0-based
    if (pageIndex < 0 || pageIndex >= pages.length) continue;

    const page = pages[pageIndex];
    const { width: pageWidthPt, height: pageHeightPt } = page.getSize();

    for (const rec of records) {
      try {
        // ─── Resolve bytes in the correct format ───────────────────────────
        let imgBytes = rec.bytes;    // ArrayBuffer | null
        let imgFormat = rec.format;  // 'png'|'jpg'|'webp'|'svg'

        if (imgFormat === 'svg') {
          // Rasterise SVG → PNG at 300 DPI (pdf-lib has no SVG support)
          imgBytes = await rasteriseSvg(rec.dataUrl, 300);
          imgFormat = 'png';
        } else if (imgFormat === 'webp') {
          // Convert WebP → PNG (pdf-lib only supports PNG and JPEG)
          imgBytes = await webpToPng(rec.dataUrl);
          imgFormat = 'png';
        } else if (!imgBytes) {
          // Fallback: decode the data URL if raw bytes are missing
          const b64 = rec.dataUrl.split(',')[1];
          imgBytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0)).buffer;
        }

        // ─── Embed image into pdf-lib ──────────────────────────────────────
        let embeddedImage;
        const uint8 = new Uint8Array(imgBytes);

        if (imgFormat === 'png' || isPng(imgBytes)) {
          embeddedImage = await pdfDoc.embedPng(uint8);
        } else if (imgFormat === 'jpg' || isJpeg(imgBytes)) {
          embeddedImage = await pdfDoc.embedJpg(uint8);
        } else {
          // Last resort: try PNG, then JPEG
          try      { embeddedImage = await pdfDoc.embedPng(uint8); }
          catch(_) { embeddedImage = await pdfDoc.embedJpg(uint8); }
        }

        // ─── Coordinate transformation ─────────────────────────────────────
        //  rec.renderScale  = the Fabric canvas zoom (1.0 at native size)
        //  rec.naturalW/H   = page natural size in CSS pixels (at scale=1)
        //  All Fabric positions are already in natural (scale=1) coordinates
        //  because we divide by currentScale in FabricOverlay.getAllImageData().
        const s = rec.renderScale;

        // Canvas px → PDF points
        const pxToPt = pageWidthPt / (rec.naturalW * s);
        const pxToPtY = pageHeightPt / (rec.naturalH * s);

        const scaledW = rec.width  * rec.scaleX;  // canvas px
        const scaledH = rec.height * rec.scaleY;  // canvas px

        const halfW_pt = (scaledW / 2) * pxToPt;
        const halfH_pt = (scaledH / 2) * pxToPtY;

        const centerFabricX = rec.left + scaledW / 2;
        const centerFabricY = rec.top  + scaledH / 2;

        const centerPdfX = centerFabricX * pxToPt;
        const centerPdfY = pageHeightPt - centerFabricY * pxToPtY;  // y-flip

        // Rotation: Fabric angle is CW degrees; in PDF (y-up) that becomes the
        // same CCW angle.  pdf-lib degrees() treats positive values as CCW.
        const α = rec.angle;  // degrees (CW in Fabric → CCW in PDF)
        const θ = (α * Math.PI) / 180;
        const cosA = Math.cos(θ);
        const sinA = Math.sin(θ);

        // Anchor = image's bottom-left after rotation around its centre
        const anchorX = centerPdfX - halfW_pt * cosA - halfH_pt * sinA;
        const anchorY = centerPdfY - halfW_pt * sinA - halfH_pt * cosA;

        page.drawImage(embeddedImage, {
          x:       anchorX,
          y:       anchorY,
          width:   halfW_pt * 2,
          height:  halfH_pt * 2,
          rotate:  degrees(α),
          opacity: rec.opacity ?? 1,
        });

      } catch (err) {
        // Log and skip this image — don't crash the whole save
        console.error(`[saveManager] Failed to embed image on page ${pageNum}:`, err);
      }
    }
  }

  // ─── Serialise and download ─────────────────────────────────────────────────
  const pdfBytes = await pdfDoc.save();
  const blob = new Blob([pdfBytes], { type: 'application/pdf' });
  const dataUrl = URL.createObjectURL(blob);

  // Trigger download through the background service worker so we stay within
  // the extension's download permission boundary.
  chrome.runtime.sendMessage({
    type: 'download',
    dataUrl,
    filename: filename || 'document.pdf',
  }, () => {
    // Revoke blob URL shortly after; if the download hasn't started by then
    // Edge will still have the bytes in the download system.
    setTimeout(() => URL.revokeObjectURL(dataUrl), 30_000);
  });
}
