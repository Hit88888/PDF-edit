/**
 * snapGuides.js — Snap-to-edge/center/corner logic and visual guide lines.
 *
 * Snap targets per page: edges (top, bottom, left, right), center (X, Y),
 * and corners. Guide lines are rendered as absolutely-positioned divs layered
 * over the page container.
 */

const SNAP_TOLERANCE = 10; // pixels — distance within which snapping activates

export class SnapGuides {
  /**
   * @param {HTMLElement} pageContainer  The div that wraps a single PDF page.
   * @param {number} canvasWidth         Rendered canvas width in pixels.
   * @param {number} canvasHeight        Rendered canvas height in pixels.
   */
  constructor(pageContainer, canvasWidth, canvasHeight) {
    this._container = pageContainer;
    this._w = canvasWidth;
    this._h = canvasHeight;
    this._guides = []; // active guide line elements
  }

  /** Update dimensions when zoom changes. */
  resize(canvasWidth, canvasHeight) {
    this._w = canvasWidth;
    this._h = canvasHeight;
  }

  /**
   * Given the proposed top-left (x, y) and dimensions (w, h) of an object
   * (in Fabric canvas coordinates), return { x, y } snapped to the nearest
   * snap target if within SNAP_TOLERANCE, plus show guide lines for active snaps.
   *
   * @param {number} x  Proposed left edge of object.
   * @param {number} y  Proposed top edge of object.
   * @param {number} w  Object width (scaled).
   * @param {number} h  Object height (scaled).
   * @returns {{ x: number, y: number }}
   */
  snap(x, y, w, h) {
    this.clearGuides();

    const cx = x + w / 2; // object center X
    const cy = y + h / 2; // object center Y
    const pageHalfW = this._w / 2;
    const pageHalfH = this._h / 2;

    let snappedX = x;
    let snappedY = y;

    // Horizontal snap targets: left edge, center, right edge
    const hTargets = [
      { pos: 0,         fromLeft: true },  // page left edge → object left edge
      { pos: pageHalfW, fromLeft: false }, // page center → object center
      { pos: this._w,   fromLeft: false }, // page right edge → object right edge (special)
    ];

    for (const t of hTargets) {
      let objEdge, diff;
      if (t.pos === 0) {
        objEdge = x;
        diff = Math.abs(objEdge - t.pos);
        if (diff < SNAP_TOLERANCE) { snappedX = t.pos; this._addGuide('v', t.pos); break; }
      } else if (t.pos === pageHalfW) {
        objEdge = cx;
        diff = Math.abs(objEdge - t.pos);
        if (diff < SNAP_TOLERANCE) { snappedX = t.pos - w / 2; this._addGuide('v', t.pos); break; }
      } else {
        objEdge = x + w;
        diff = Math.abs(objEdge - t.pos);
        if (diff < SNAP_TOLERANCE) { snappedX = t.pos - w; this._addGuide('v', t.pos); break; }
      }
    }

    // Vertical snap targets: top edge, center, bottom edge
    const vTargets = [
      { pos: 0 },           // page top → object top
      { pos: pageHalfH },   // page center → object center
      { pos: this._h },     // page bottom → object bottom
    ];

    for (const t of vTargets) {
      let objEdge, diff;
      if (t.pos === 0) {
        objEdge = y;
        diff = Math.abs(objEdge - t.pos);
        if (diff < SNAP_TOLERANCE) { snappedY = t.pos; this._addGuide('h', t.pos); break; }
      } else if (t.pos === pageHalfH) {
        objEdge = cy;
        diff = Math.abs(objEdge - t.pos);
        if (diff < SNAP_TOLERANCE) { snappedY = t.pos - h / 2; this._addGuide('h', t.pos); break; }
      } else {
        objEdge = y + h;
        diff = Math.abs(objEdge - t.pos);
        if (diff < SNAP_TOLERANCE) { snappedY = t.pos - h; this._addGuide('h', t.pos); break; }
      }
    }

    return { x: snappedX, y: snappedY };
  }

  /** Remove all currently visible guide lines. */
  clearGuides() {
    for (const el of this._guides) el.remove();
    this._guides = [];
  }

  /**
   * @param {'h'|'v'} axis
   * @param {number}  pos   Position in pixels along the axis.
   */
  _addGuide(axis, pos) {
    const el = document.createElement('div');
    el.className = 'snap-guide snap-guide-' + axis;
    if (axis === 'h') {
      el.style.top = pos + 'px';
    } else {
      el.style.left = pos + 'px';
    }
    this._container.appendChild(el);
    this._guides.push(el);
  }
}
