/**
 * toolbar.js — Floating draggable toolbar component.
 *
 * Renders a dark glassmorphism toolbar. Each action button emits a custom
 * event on the toolbar element so viewer.js can listen centrally.
 *
 * Usage:
 *   const tb = new Toolbar(document.body);
 *   tb.element.addEventListener('tb:addImage',   () => ...);
 *   tb.element.addEventListener('tb:undo',        () => ...);
 *   ...
 */

const ICONS = {
  addImage:     `<svg viewBox="0 0 20 20" fill="none"><rect x="2" y="4" width="16" height="12" rx="2" stroke="currentColor" stroke-width="1.5"/><circle cx="7" cy="9" r="1.5" fill="currentColor"/><path d="M2 14l4-4 3 3 3-3 6 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 2v4M12 4h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
  undo:         `<svg viewBox="0 0 20 20" fill="none"><path d="M4 8H12a5 5 0 010 10H8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 8l3-3M4 8l3 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  redo:         `<svg viewBox="0 0 20 20" fill="none"><path d="M16 8H8a5 5 0 000 10h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 8l-3-3M16 8l-3 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  delete:       `<svg viewBox="0 0 20 20" fill="none"><path d="M6 5V4a2 2 0 012-2h4a2 2 0 012 2v1M3 5h14M8 9v6M12 9v6M4 5l1 12h10L16 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  duplicate:    `<svg viewBox="0 0 20 20" fill="none"><rect x="7" y="7" width="10" height="10" rx="1.5" stroke="currentColor" stroke-width="1.5"/><path d="M4 13V4a1 1 0 011-1h9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
  bringFwd:     `<svg viewBox="0 0 20 20" fill="none"><rect x="6" y="6" width="10" height="10" rx="1.5" fill="currentColor" opacity="0.25"/><rect x="4" y="4" width="10" height="10" rx="1.5" stroke="currentColor" stroke-width="1.5"/><path d="M14 4V2M14 2l-2 2M14 2l2 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  sendBwd:      `<svg viewBox="0 0 20 20" fill="none"><rect x="4" y="4" width="10" height="10" rx="1.5" fill="currentColor" opacity="0.25"/><rect x="6" y="6" width="10" height="10" rx="1.5" stroke="currentColor" stroke-width="1.5"/><path d="M6 16v2M6 18l-2-2M6 18l2-2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  rotateL:      `<svg viewBox="0 0 20 20" fill="none"><path d="M5 9A7 7 0 1010 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M10 3L8 6M10 3l3 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  rotateR:      `<svg viewBox="0 0 20 20" fill="none"><path d="M15 9A7 7 0 1010 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M10 3l2 3M10 3L7 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  flipH:        `<svg viewBox="0 0 20 20" fill="none"><path d="M10 3v14M3 7l4 3-4 3V7zM17 7l-4 3 4 3V7z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  flipV:        `<svg viewBox="0 0 20 20" fill="none"><path d="M3 10h14M7 3l3 4 3-4H7zM7 17l3-4 3 4H7z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  lock:         `<svg viewBox="0 0 20 20" fill="none"><rect x="4" y="9" width="12" height="9" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M7 9V6a3 3 0 016 0v3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="10" cy="14" r="1.5" fill="currentColor"/></svg>`,
  unlock:       `<svg viewBox="0 0 20 20" fill="none"><rect x="4" y="9" width="12" height="9" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M7 9V6a3 3 0 016 0" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="10" cy="14" r="1.5" fill="currentColor" opacity="0.4"/></svg>`,
  reset:        `<svg viewBox="0 0 20 20" fill="none"><path d="M4 10a6 6 0 106-6H8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M8 4L6 7l3 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="7" y1="10" x2="13" y2="16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><line x1="13" y1="10" x2="7" y2="16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
  save:         `<svg viewBox="0 0 20 20" fill="none"><path d="M5 17H3a1 1 0 01-1-1V4a1 1 0 011-1h10l4 4v10a1 1 0 01-1 1h-2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><rect x="7" y="12" width="6" height="5" rx="1" stroke="currentColor" stroke-width="1.5"/><path d="M7 3v4h7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  cancel:       `<svg viewBox="0 0 20 20" fill="none"><path d="M5 5l10 10M15 5L5 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
  opacity:      `<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M10 3v14" stroke="currentColor" stroke-width="1.5"/><path fill="currentColor" opacity="0.5" d="M10 3a7 7 0 000 14V3z"/></svg>`,
  drag:         `<svg viewBox="0 0 20 20" fill="none"><circle cx="7.5" cy="5" r="1" fill="currentColor"/><circle cx="12.5" cy="5" r="1" fill="currentColor"/><circle cx="7.5" cy="10" r="1" fill="currentColor"/><circle cx="12.5" cy="10" r="1" fill="currentColor"/><circle cx="7.5" cy="15" r="1" fill="currentColor"/><circle cx="12.5" cy="15" r="1" fill="currentColor"/></svg>`,
};

function btn(id, icon, label, extra = '') {
  return `<button class="tb-btn" data-action="${id}" title="${label}" ${extra}>${ICONS[icon]}</button>`;
}

function sep() {
  return `<div class="tb-sep"></div>`;
}

export class Toolbar {
  /** @param {HTMLElement} mountTarget  Element to append the toolbar to. */
  constructor(mountTarget) {
    this.element = document.createElement('div');
    this.element.className = 'toolbar';
    this.element.innerHTML = `
      <div class="tb-drag-handle" title="Drag to move toolbar">${ICONS.drag}</div>
      ${btn('addImage',  'addImage',  'Add Image (A)')}
      ${sep()}
      <button class="tb-btn" data-action="undo" id="tb-undo" title="Undo (Ctrl+Z)">${ICONS.undo}</button>
      <button class="tb-btn" data-action="redo" id="tb-redo" title="Redo (Ctrl+Shift+Z)">${ICONS.redo}</button>
      ${sep()}
      ${btn('delete',    'delete',    'Delete selected (Del)')}
      ${btn('duplicate', 'duplicate', 'Duplicate (Ctrl+D)')}
      ${sep()}
      ${btn('bringFwd',  'bringFwd',  'Bring Forward')}
      ${btn('sendBwd',   'sendBwd',   'Send Backward')}
      ${sep()}
      ${btn('rotateL',   'rotateL',   'Rotate Left 15°')}
      ${btn('rotateR',   'rotateR',   'Rotate Right 15°')}
      ${sep()}
      ${btn('flipH',     'flipH',     'Flip Horizontal')}
      ${btn('flipV',     'flipV',     'Flip Vertical')}
      ${sep()}
      <div class="tb-opacity-wrap" title="Opacity">
        ${ICONS.opacity}
        <input type="range" id="tb-opacity" min="0" max="100" value="100" step="1" class="tb-slider"/>
        <span id="tb-opacity-val" class="tb-slider-val">100%</span>
      </div>
      ${sep()}
      <button class="tb-btn" data-action="lock" id="tb-lock" title="Lock / Unlock">${ICONS.lock}</button>
      ${sep()}
      ${btn('reset',     'reset',     'Remove all images from this page')}
      ${sep()}
      ${btn('save',      'save',      'Save PDF (Ctrl+S)')}
      ${btn('cancel',    'cancel',    'Close Editor')}
    `;

    mountTarget.appendChild(this.element);
    this._makeDraggable();
    this._bindActions();
    this._opacityLocked = false;
  }

  // ---------------------------------------------------------------------------
  // State updates called by viewer.js
  // ---------------------------------------------------------------------------

  setUndoEnabled(enabled) {
    const el = this.element.querySelector('#tb-undo');
    if (el) el.disabled = !enabled;
  }

  setRedoEnabled(enabled) {
    const el = this.element.querySelector('#tb-redo');
    if (el) el.disabled = !enabled;
  }

  /** Update opacity slider to reflect the selected object's opacity. */
  setOpacityValue(value01) {
    const pct = Math.round(value01 * 100);
    const slider = this.element.querySelector('#tb-opacity');
    const label  = this.element.querySelector('#tb-opacity-val');
    if (slider) slider.value = pct;
    if (label)  label.textContent = pct + '%';
  }

  /** Update the lock button icon to reflect current lock state. */
  setLocked(isLocked) {
    const btn = this.element.querySelector('#tb-lock');
    if (btn) btn.innerHTML = isLocked ? ICONS.unlock : ICONS.lock;
  }

  // ---------------------------------------------------------------------------
  // Saving state indicator
  // ---------------------------------------------------------------------------

  setSaving(isSaving) {
    const btn = this.element.querySelector('[data-action="save"]');
    if (!btn) return;
    btn.disabled = isSaving;
    btn.innerHTML = isSaving
      ? `<svg class="tb-spin" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5" stroke-dasharray="22 22" stroke-linecap="round"/></svg>`
      : ICONS.save;
  }

  // ---------------------------------------------------------------------------
  // Internal wiring
  // ---------------------------------------------------------------------------

  _bindActions() {
    // Button clicks → emit named event
    this.element.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn || btn.disabled) return;
      const action = btn.dataset.action;
      this._emit('tb:' + action);
    });

    // Opacity slider
    const opacitySlider = this.element.querySelector('#tb-opacity');
    const opacityLabel  = this.element.querySelector('#tb-opacity-val');
    if (opacitySlider) {
      opacitySlider.addEventListener('input', () => {
        const pct = parseInt(opacitySlider.value, 10);
        if (opacityLabel) opacityLabel.textContent = pct + '%';
        this._emit('tb:opacity', { value: pct / 100 });
      });
    }
  }

  _emit(name, detail = {}) {
    this.element.dispatchEvent(new CustomEvent(name, { bubbles: true, detail }));
  }

  _makeDraggable() {
    const handle = this.element.querySelector('.tb-drag-handle');
    if (!handle) return;

    let dragging = false;
    let startX, startY, origLeft, origTop;

    handle.addEventListener('mousedown', (e) => {
      e.preventDefault();
      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = this.element.getBoundingClientRect();
      origLeft = rect.left;
      origTop  = rect.top;
      this.element.style.transition = 'none';
    });

    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      let newLeft = origLeft + dx;
      let newTop  = origTop  + dy;

      // Keep within viewport
      const tbW = this.element.offsetWidth;
      const tbH = this.element.offsetHeight;
      newLeft = Math.max(8, Math.min(window.innerWidth  - tbW - 8, newLeft));
      newTop  = Math.max(8, Math.min(window.innerHeight - tbH - 8, newTop));

      this.element.style.left = newLeft + 'px';
      this.element.style.top  = newTop  + 'px';
      this.element.style.right  = 'auto';
      this.element.style.bottom = 'auto';
    });

    document.addEventListener('mouseup', () => { dragging = false; });
  }
}
