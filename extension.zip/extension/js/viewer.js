/**
 * viewer.js — Main orchestrator for the PDF editor viewer page.
 *
 * Responsibilities:
 *   - Parse the ?src= URL parameter and load the PDF.
 *   - Build the per-page DOM structure.
 *   - Use IntersectionObserver for virtualized rendering (only render
 *     pages within the viewport ± a buffer).
 *   - Wire together PdfRenderer, FabricOverlay, Toolbar, History, and SaveManager.
 *   - Handle keyboard shortcuts and toolbar events.
 *   - Manage zoom level.
 */

import { PdfRenderer }  from './pdfRenderer.js';
import { FabricOverlay } from './fabricOverlay.js';
import { Toolbar }       from './toolbar.js';
import { History }       from './history.js';
import { savePdf }       from './saveManager.js';

// ─── Constants ──────────────────────────────────────────────────────────────

const ZOOM_STEP      = 0.25;
const ZOOM_MIN       = 0.5;
const ZOOM_MAX       = 4.0;
const VIEWPORT_BUFFER = 1200; // px above/below viewport to pre-render
const BASE_SCALE     = 1.5;   // default render scale (1.5 × natural CSS px)

// ─── State ───────────────────────────────────────────────────────────────────

let scale       = BASE_SCALE;
let numPages    = 0;
let currentPage = 1; // 1-based, tracks last page user scrolled to
let pdfFilename = 'document.pdf';

/** @type {PdfRenderer} */
let renderer;
/** @type {FabricOverlay} */
let overlay;
/** @type {Toolbar} */
let toolbar;
/** @type {History} */
let history;
/** @type {Map<number, HTMLElement>}  pageNum → page wrapper div */
const pageElements = new Map();
/** @type {IntersectionObserver} */
let observer;

// ─── DOM refs ────────────────────────────────────────────────────────────────
const $container  = document.getElementById('pages-container');
const $loading    = document.getElementById('loading-overlay');
const $error      = document.getElementById('error-overlay');
const $errorMsg   = document.getElementById('error-message');
const $zoomLabel  = document.getElementById('zoom-label');
const $fileInput  = document.createElement('input');
$fileInput.type   = 'file';
$fileInput.accept = 'image/png,image/jpeg,image/webp,image/svg+xml';
$fileInput.multiple = true;

// ─── Entry point ─────────────────────────────────────────────────────────────

async function main() {
  showLoading('Initialising…');

  // Parse source URL from query string
  const params = new URL(location.href).searchParams;
  const srcUrl = params.get('src');
  if (!srcUrl) {
    showError('No PDF source specified. Open a PDF and click the extension icon.');
    return;
  }

  // Derive filename
  try {
    const u = new URL(srcUrl);
    const parts = u.pathname.split('/');
    pdfFilename = decodeURIComponent(parts[parts.length - 1]) || 'document.pdf';
    if (!pdfFilename.toLowerCase().endsWith('.pdf')) pdfFilename += '.pdf';
  } catch { /* ignore */ }

  // Set up auxiliary objects
  history = new History();
  renderer = new PdfRenderer();
  overlay  = new FabricOverlay({
    history,
    onSelectionChange: handleSelectionChange,
    onModified: () => {},
  });

  // Toolbar (mounted to body)
  toolbar = new Toolbar(document.body);
  bindToolbarEvents();

  // History → toolbar sync
  history.onChange(({ canUndo, canRedo }) => {
    toolbar.setUndoEnabled(canUndo);
    toolbar.setRedoEnabled(canRedo);
  });
  toolbar.setUndoEnabled(false);
  toolbar.setRedoEnabled(false);

  // Load PDF
  showLoading('Loading PDF…');
  try {
    await renderer.load(srcUrl, promptPassword);
  } catch (err) {
    showError('Failed to load PDF: ' + err.message +
      (srcUrl.startsWith('file://') ? '\n\nTip: make sure "Allow access to file URLs" is enabled for this extension in edge://extensions' : ''));
    return;
  }

  numPages = renderer.numPages;
  document.title = pdfFilename + ' — PDF Image Editor';

  // Build page scaffold
  showLoading(`Rendering ${numPages} page${numPages > 1 ? 's' : ''}…`);
  await buildPageScaffold();

  // Start virtualized rendering
  setupObserver();
  // Track which page is most visible as user scrolls
  setupScrollTracking();
  updateZoomLabel();
  hideLoading();

  // Keyboard shortcuts
  document.addEventListener('keydown', handleKeydown);
}

// ─── Page scaffold ────────────────────────────────────────────────────────────

/**
 * For each PDF page, create a placeholder div whose height matches the
 * page's natural size × scale. The IntersectionObserver will trigger
 * actual rendering as each placeholder enters the viewport.
 */
async function buildPageScaffold() {
  for (let p = 1; p <= numPages; p++) {
    const natural = await renderer.getPageNaturalSize(p);
    overlay.registerPage(p, natural.width, natural.height);

    const wrapper = document.createElement('div');
    wrapper.className = 'page-wrapper';
    wrapper.dataset.page = p;

    const w = Math.round(natural.width  * scale);
    const h = Math.round(natural.height * scale);
    wrapper.style.width  = w + 'px';
    wrapper.style.height = h + 'px';

    // PDF canvas placeholder
    const pdfCanvas = document.createElement('canvas');
    pdfCanvas.className = 'pdf-canvas';
    wrapper.appendChild(pdfCanvas);

    // Page number label
    const label = document.createElement('div');
    label.className = 'page-label';
    label.textContent = `${p} / ${numPages}`;
    wrapper.appendChild(label);

    $container.appendChild(wrapper);
    pageElements.set(p, wrapper);
  }
}

// ─── Virtualised rendering ────────────────────────────────────────────────────

function setupObserver() {
  if (observer) observer.disconnect();

  const rootMargin = VIEWPORT_BUFFER + 'px 0px';
  observer = new IntersectionObserver(handleIntersection, {
    root: null,
    rootMargin,
    threshold: 0,
  });

  for (const [, el] of pageElements) observer.observe(el);
}

async function handleIntersection(entries) {
  for (const entry of entries) {
    const pageNum = parseInt(entry.target.dataset.page, 10);
    if (entry.isIntersecting) {
      await renderPageVisible(pageNum, entry.target);
    } else {
      unloadPageOffscreen(pageNum);
    }
  }
}

async function renderPageVisible(pageNum, wrapper) {
  const pdfCanvas = wrapper.querySelector('.pdf-canvas');
  if (!pdfCanvas) return;

  // Render PDF page
  try {
    const dims = await renderer.renderPage(pageNum, pdfCanvas, scale);
    if (!dims) return; // cancelled

    // Size the wrapper to match
    wrapper.style.width  = dims.width  + 'px';
    wrapper.style.height = dims.height + 'px';

    // Attach Fabric overlay
    await overlay.attachPage(pageNum, wrapper, scale);
  } catch (err) {
    console.error(`[viewer] Error rendering page ${pageNum}:`, err);
  }
}

function unloadPageOffscreen(pageNum) {
  renderer.cancelRender(pageNum);
  overlay.detachPage(pageNum);

  const wrapper = pageElements.get(pageNum);
  if (wrapper) {
    // Remove Fabric canvas element (serialised state is kept in overlay)
    const fc = wrapper.querySelector('.fabric-canvas');
    if (fc) fc.remove();

    // Clear PDF canvas pixels to free GPU memory
    const pdfCanvas = wrapper.querySelector('.pdf-canvas');
    if (pdfCanvas) {
      const ctx = pdfCanvas.getContext('2d');
      ctx?.clearRect(0, 0, pdfCanvas.width, pdfCanvas.height);
    }
  }
}

// ─── Zoom ─────────────────────────────────────────────────────────────────────

async function applyZoom(newScale) {
  newScale = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, newScale));
  if (newScale === scale) return;

  // Capture scroll position relative to viewport centre before zoom
  const scrollEl   = document.documentElement;
  const viewCentre = scrollEl.scrollTop + window.innerHeight / 2;
  const oldTotal   = scrollEl.scrollHeight;

  scale = newScale;

  // Resize all page wrappers proportionally
  for (const [pageNum, wrapper] of pageElements) {
    const page = await renderer.getPageNaturalSize(pageNum);
    const w = Math.round(page.width  * scale);
    const h = Math.round(page.height * scale);
    wrapper.style.width  = w + 'px';
    wrapper.style.height = h + 'px';
  }

  // Re-trigger observer so newly visible pages render at new scale
  observer.disconnect();
  // Re-render all currently visible pages at the new scale
  for (const [pageNum, wrapper] of pageElements) {
    const rect = wrapper.getBoundingClientRect();
    const isVisible = rect.bottom > -VIEWPORT_BUFFER && rect.top < window.innerHeight + VIEWPORT_BUFFER;
    if (isVisible) {
      await renderPageVisible(pageNum, wrapper);
    } else {
      unloadPageOffscreen(pageNum);
    }
  }
  setupObserver();

  // Scale all Fabric overlays (attached pages)
  await overlay.setScale(scale);

  // Restore scroll position proportionally
  const newTotal = document.documentElement.scrollHeight;
  document.documentElement.scrollTop = (viewCentre / oldTotal) * newTotal - window.innerHeight / 2;

  updateZoomLabel();
}

function updateZoomLabel() {
  if ($zoomLabel) $zoomLabel.textContent = Math.round(scale / BASE_SCALE * 100) + '%';
}

// ─── Toolbar events ───────────────────────────────────────────────────────────

function bindToolbarEvents() {
  const tb = toolbar.element;

  tb.addEventListener('tb:addImage',  () => $fileInput.click());
  tb.addEventListener('tb:undo',      () => history.undo());
  tb.addEventListener('tb:redo',      () => history.redo());
  tb.addEventListener('tb:delete',    () => overlay.deleteSelected(currentPage));
  tb.addEventListener('tb:duplicate', () => overlay.duplicateSelected(currentPage));
  tb.addEventListener('tb:bringFwd',  () => overlay.bringForward(currentPage));
  tb.addEventListener('tb:sendBwd',   () => overlay.sendBackward(currentPage));
  tb.addEventListener('tb:rotateL',   () => overlay.rotateSelected(currentPage, -15));
  tb.addEventListener('tb:rotateR',   () => overlay.rotateSelected(currentPage, +15));
  tb.addEventListener('tb:flipH',     () => overlay.flipHorizontal(currentPage));
  tb.addEventListener('tb:flipV',     () => overlay.flipVertical(currentPage));
  tb.addEventListener('tb:lock',      () => {
    const locked = overlay.toggleLock(currentPage);
    if (locked !== undefined) toolbar.setLocked(locked);
  });
  tb.addEventListener('tb:reset',     () => {
    if (confirm('Remove all images from this page?')) overlay.resetPage(currentPage);
  });
  tb.addEventListener('tb:opacity',   (e) => overlay.setOpacity(currentPage, e.detail.value));
  tb.addEventListener('tb:save',      () => doSave());
  tb.addEventListener('tb:cancel',    () => {
    if (confirm('Close the editor? Any unsaved changes will be lost.')) {
      history.clear();
      window.close();
    }
  });

  // File input → add images
  $fileInput.addEventListener('change', async () => {
    const files = Array.from($fileInput.files ?? []);
    $fileInput.value = '';
    for (const file of files) {
      await handleImageFile(file);
    }
  });
}

/** Handle an image file dropped or selected by the user. */
async function handleImageFile(file) {
  const allowed = ['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml'];
  if (!allowed.includes(file.type)) {
    alert(`Unsupported image format: ${file.type}. Accepted: PNG, JPG, WEBP, SVG.`);
    return;
  }

  // Memory guard: warn on very large files
  if (file.size > 50 * 1024 * 1024) {
    const go = confirm(`"${file.name}" is ${(file.size / 1024 / 1024).toFixed(1)} MB. Very large images may cause slowness. Continue?`);
    if (!go) return;
  }

  try {
    const bytes  = await file.arrayBuffer();
    const format = file.type === 'image/jpeg' ? 'jpg'
                 : file.type === 'image/svg+xml' ? 'svg'
                 : file.type === 'image/webp'    ? 'webp'
                 : 'png';

    const dataUrl = await fileToDataUrl(file);
    await overlay.addImage(currentPage, dataUrl, format, bytes);
  } catch (err) {
    console.error('[viewer] Failed to add image:', err);
    alert(`Could not add image "${file.name}": ${err.message}`);
  }
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

// ─── Selection change ─────────────────────────────────────────────────────────

function handleSelectionChange(pageNum, obj) {
  if (obj) {
    toolbar.setOpacityValue(obj.opacity ?? 1);
    toolbar.setLocked(obj.get?.('locked') ?? false);
  }
}

// ─── Save ─────────────────────────────────────────────────────────────────────

async function doSave() {
  const imageData = overlay.getAllImageData();
  if (imageData.size === 0) {
    alert('No images have been added yet.');
    return;
  }
  toolbar.setSaving(true);
  try {
    await savePdf(renderer.originalBytes, imageData, pdfFilename);
    // Close tab after download is triggered (per user preference)
    setTimeout(() => window.close(), 800);
  } catch (err) {
    console.error('[viewer] Save failed:', err);
    alert('Save failed: ' + err.message);
  } finally {
    toolbar.setSaving(false);
  }
}

// ─── Keyboard shortcuts ───────────────────────────────────────────────────────

function handleKeydown(e) {
  const ctrl  = e.ctrlKey || e.metaKey;
  const shift = e.shiftKey;

  // Guard: if focus is inside an input/slider, skip most shortcuts
  const tag = document.activeElement?.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA') return;

  if (ctrl && !shift && e.key === 'z') { e.preventDefault(); history.undo(); return; }
  if (ctrl &&  shift && e.key === 'z') { e.preventDefault(); history.redo(); return; }
  if (ctrl && e.key === 'y')           { e.preventDefault(); history.redo(); return; }
  if (ctrl && e.key === 's')           { e.preventDefault(); doSave();       return; }
  if (ctrl && e.key === 'd')           { e.preventDefault(); overlay.duplicateSelected(currentPage); return; }
  if (ctrl && e.key === 'a')           { e.preventDefault(); $fileInput.click(); return; }

  if (e.key === 'Delete' || e.key === 'Backspace') {
    const tag2 = document.activeElement?.tagName;
    if (tag2 !== 'INPUT' && tag2 !== 'TEXTAREA') {
      overlay.deleteSelected(currentPage);
    }
    return;
  }

  if (e.key === 'Escape') {
    // Deselect all (Fabric handles this via canvas click, but ESC also works)
    return;
  }

  // Zoom: Ctrl+= / Ctrl+-
  if (ctrl && (e.key === '=' || e.key === '+')) { e.preventDefault(); applyZoom(scale + ZOOM_STEP); }
  if (ctrl && e.key === '-')                    { e.preventDefault(); applyZoom(scale - ZOOM_STEP); }
  if (ctrl && e.key === '0')                    { e.preventDefault(); applyZoom(BASE_SCALE); }

  // Arrow-key nudge for selected object
  const nudge = shift ? 10 : 1;
  const selected = overlay.getSelected(currentPage);
  if (selected && ['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)) {
    e.preventDefault();
    const page = pageElements.get(currentPage);
    const fc   = page?.querySelector('.fabric-canvas')?._fabricCanvas;
    const dx = e.key === 'ArrowLeft' ? -nudge : e.key === 'ArrowRight' ? nudge : 0;
    const dy = e.key === 'ArrowUp'   ? -nudge : e.key === 'ArrowDown'  ? nudge : 0;
    selected.set({ left: selected.left + dx, top: selected.top + dy });
    selected.setCoords();
    // Re-render the Fabric canvas for this page
    const fabricEl = page?.querySelector('.fabric-canvas');
    if (fabricEl?.fabric) { fabricEl.fabric.renderAll(); }
    // Access canvas via overlay internal (simpler approach):
    const p = overlay._pages?.get(currentPage);
    if (p?.canvas) p.canvas.renderAll();
  }
}

// ─── Password prompt ──────────────────────────────────────────────────────────

function promptPassword(reason) {
  const msg = reason === 1
    ? 'This PDF is password-protected. Enter the password:'
    : 'Incorrect password. Try again:';
  return prompt(msg) ?? '';
}

// ─── Scroll tracking (update currentPage) ────────────────────────────────────

function setupScrollTracking() {
  const io = new IntersectionObserver((entries) => {
    let bestRatio = 0;
    for (const entry of entries) {
      if (entry.intersectionRatio > bestRatio) {
        bestRatio = entry.intersectionRatio;
        currentPage = parseInt(entry.target.dataset.page, 10);
      }
    }
  }, { threshold: [0.1, 0.5, 1.0] });
  for (const [, el] of pageElements) io.observe(el);
}

// ─── Zoom controls (header buttons) ──────────────────────────────────────────

function bindZoomControls() {
  document.getElementById('btn-zoom-in')?.addEventListener('click', () => applyZoom(scale + ZOOM_STEP));
  document.getElementById('btn-zoom-out')?.addEventListener('click', () => applyZoom(scale - ZOOM_STEP));
  document.getElementById('btn-zoom-reset')?.addEventListener('click', () => applyZoom(BASE_SCALE));
}

// ─── Loading / error overlays ─────────────────────────────────────────────────

function showLoading(msg) {
  if ($loading) {
    $loading.style.display = 'flex';
    const span = $loading.querySelector('span');
    if (span) span.textContent = msg;
  }
}
function hideLoading() {
  if ($loading) $loading.style.display = 'none';
}
function showError(msg) {
  hideLoading();
  if ($error) $error.style.display = 'flex';
  if ($errorMsg) $errorMsg.textContent = msg;
  console.error('[viewer] Error:', msg);
}

// ─── Bootstrap ───────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  bindZoomControls();
  // Note: setupScrollTracking() is called inside main() after buildPageScaffold()
  // so that pageElements is populated before we attach the IntersectionObserver.
  main().catch((err) => showError('Unexpected error: ' + err.message));
});
