/**
 * popup.js — Extension action popup logic.
 *
 * Determines the state of the current tab and shows the appropriate UI:
 *   - PDF detected → "Open in Editor" button
 *   - Already in the viewer → "Editor is active" message
 *   - Not a PDF → "Not a PDF page" message
 */

/** Returns the filename portion of a URL, or a shortened form of the URL. */
function labelFromUrl(url) {
  try {
    const u = new URL(url);
    const parts = u.pathname.split('/');
    const last = parts[parts.length - 1];
    return last ? decodeURIComponent(last) : u.hostname;
  } catch {
    return url.slice(0, 40);
  }
}

/** True if the URL appears to be a PDF (by extension or chrome-extension viewer). */
function looksLikePdf(url) {
  if (!url) return false;
  try {
    const u = new URL(url);
    // Already in our viewer
    if (u.pathname.endsWith('viewer.html')) return false;
    // Common PDF URL patterns
    return (
      u.pathname.toLowerCase().endsWith('.pdf') ||
      url.toLowerCase().includes('.pdf?') ||
      url.toLowerCase().includes('.pdf#')
    );
  } catch {
    return false;
  }
}

/** True if the URL is our own viewer page. */
function isViewerPage(url) {
  if (!url) return false;
  const viewerBase = chrome.runtime.getURL('viewer.html');
  return url.startsWith(viewerBase);
}

function show(id) {
  document.querySelectorAll('.state').forEach((el) => el.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}

async function init() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab || !tab.url) {
      show('state-not-pdf');
      return;
    }

    const url = tab.url;

    if (isViewerPage(url)) {
      show('state-already-editing');
      return;
    }

    if (looksLikePdf(url)) {
      document.getElementById('pdf-filename').textContent = labelFromUrl(url);
      show('state-is-pdf');

      document.getElementById('btn-open').addEventListener('click', async () => {
        try {
          await chrome.runtime.sendMessage({
            type: 'openViewer',
            tabId: tab.id,
            pdfUrl: url,
          });
          window.close(); // Close popup after navigation is requested
        } catch (err) {
          show('state-error');
          document.getElementById('error-msg').textContent = err.message;
        }
      });
      return;
    }

    show('state-not-pdf');
  } catch (err) {
    show('state-error');
    document.getElementById('error-msg').textContent = err.message;
  }
}

init();
